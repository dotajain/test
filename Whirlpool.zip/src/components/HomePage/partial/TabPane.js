import React from 'react';
import PropTypes from 'prop-types';

const TabPane = (props) => {
  return <div>{props.children}</div>;
};

TabPane.propTypes = {
  label: PropTypes.string.isRequired,
  children: PropTypes.element.isRequired,
};

export default TabPane;