import React from 'react';
import PropTypes from 'prop-types';
import CardIngredients from './CardIngredients';

// http://cakeart.thimpress.com/recipes/chocolate-crinkle-cookies/
const MainScreen = ({...props }) => (
  <div className="main-page">
    <header className="wp-header">
      <div className="container">
        <div className="row">
          <div className="col-md-12 text-center ">
            <h1>Time to Create your <br /> CHOCOLATE CAKE</h1>
            <p>Moist,delicious chocolate cake for any celebration. <br />Make the perfect cake with help from this recipe</p>
            <ul className="buttons">
              <li className="scrollToLink">
                <a target="_blank" className="thm-btn" href="#multi-page-version">Check Demos<i className="fa fa-arrow-circle-right"></i></a>
              </li>
            </ul>
            <div className="rev-scroll-btn"><span></span></div>
          </div>
        </div>
      </div>
    </header>
    <div className="cake-steps">
      <div className="cake-row">
        <div className="cake-shadow">
          <div className="row">
            <div className="col">
              <div className="cake-card">
                <div className="cake-card-wrapper">
                  <div className="cake-icon-left">
                    <div className="row">
                      <div className="icon col-md-4 col-sm-12 col-xs-4">
                        <img width="121" height="115" src="http://cakeart.thimpress.com/wp-content/uploads/2015/07/iconbox1.jpg" className="attachment-thumbnail size-thumbnail" alt="" />
                      </div>
                      <div className="content col-md-8 col-sm-12 col-xs-8">
                        <h3 className="title">Step 1</h3>
                        <div className="des">Ingredients -- Lorem ipsum dolor sit amet consectetuer aliquet.</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col">
              <div className="cake-card">
                <div className="cake-card-wrapper">
                  <div className="cake-icon-left">
                    <div className="row">
                      <div className="icon col-md-4 col-sm-12 col-xs-4">
                        <img width="121" height="115" src="http://cakeart.thimpress.com/wp-content/uploads/2015/07/iconbox2.jpg" className="attachment-thumbnail size-thumbnail" alt="" />
                      </div>
                      <div className="content col-md-8 col-sm-12 col-xs-8">
                        <h3 className="title">Step 2</h3>
                        <div className="des">Select items -- Lorem ipsum dolor sit amet consectetuer aliquet.</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col">
              <div className="cake-card">
                <div className="cake-card-wrapper">
                  <div className="cake-icon-left">
                    <div className="row">
                      <div className="icon col-md-4 col-sm-12 col-xs-4">
                        <img width="121" height="115" src="http://cakeart.thimpress.com/wp-content/uploads/2015/07/iconbox3.jpg" className="attachment-thumbnail size-thumbnail" alt="" />
                      </div>
                      <div className="content col-md-8 col-sm-12 col-xs-8">
                        <h3 className="title">Step 3</h3>
                        <div className="des">Recipes -- Lorem ipsum dolor sit amet consectetuer aliquet.</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div className="section-header">
      <h3>Ingredients</h3>
      <div className="tm-table">
        <div className="line table-cell"></div>
        <img className="table-cell" src="http://cakeart.thimpress.com/wp-content/themes/cakeart//images/cupcake.png" alt="cupcake" title="Heading image" />
        <div className="line table-cell"></div>
      </div>
    </div>
    <div className="main-section container-fluid">
      <div className="row">
        <div className="col-md-8">
          <h2 className="main-section-title">INSTRUCTIONS</h2>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
          </p>
          <div className="steps">
            <div className="steps--items">
              <h3>Step 1</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
            </div>
            <div className="steps--items">
              <h3>Step 2</h3>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
              </p>
            </div>
            <div className="steps--items">
              <h3>Step 3</h3>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
              </p>
            </div>
          </div>
        </div>
        <div className="col-md-4">
          <CardIngredients data={ingredientsData}/>
        </div>
      </div>
    </div>
    <div className="main--footer">
      <button className="btn btn-primary" onClick={props.View}>
        Evaluate Fridge
      </button>
    </div>
  </div>

);

MainScreen.propTypes = {
  View: PropTypes.func,
};
export default MainScreen;

const ingredientsData = [
  {
    id: 0,
    name: 'Sugar (2 cups)',
    available: false,
  },
  {
    id: 1,
    name: 'Cocoa powder (3/4 cups)',
    available: false,
  },
  {
    id: 2,
    name: 'Eggs (4 eggs)',
    available: false,
  },
  {
    id: 3,
    name: 'Rice milk (1 cups)',
    available: false,
  },
  {
    id: 4,
    name: 'All-purpose flour (2 cups)',
    available: false,
  },
  {
    id: 5,
    name: 'Salt (1 tsp)',
    available: false,
  },
];