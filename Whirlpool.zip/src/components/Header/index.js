import React from 'react';
import PropTypes from 'prop-types';

import prepTime from '../../assets/images/prep-time.png';
import cookTime from '../../assets/images/cook-time.png';
import yieldImage from '../../assets/images/yield.png';
import servings from '../../assets/images/servings.png';
import logo from '../../assets/images/WhirlpoolCorp-2017Logo_2C_B.png';

const Header = ({ ...props }) => (
  <nav className="navbar navbar-expand-md navbar-default fixed-top bg-white">
    <a href="#" className="navbar-brand">
      <img width="120" src={logo} alt="Whirlphool Logo" />
    </a>
    <div className="collapse navbar-collapse">
      <div className="recipe-other">
        <div className="recipe-detail-other">
          <div className="row">
            <div className="col-md-3 col-sm-3 col-xs-6 recipe-detail-component">
              <div className="col-md-4">
                <img src={prepTime} alt="recipe detail" />
              </div>
              <div className="col-md-8">
                <em>Prep Time</em>
                <p className="detail-info">5 minutes</p>
              </div>
            </div>
            <div className="col-md-3 col-sm-3 col-xs-6 recipe-detail-component">
              <div className="col-md-4">
                <img src={cookTime} alt="recipe detail" />
              </div>
              <div className="col-md-8">
                <em>Cook Time</em>
                <p className="detail-info">10 minutes</p>
              </div>
            </div>
            <div className="col-md-3 col-sm-3 col-xs-6 recipe-detail-component">
              <div className="col-md-4">
                <img src={yieldImage} alt="recipe detail" />
              </div>
              <div className="col-md-8">
                <em>Yield</em>
                <p className="detail-info">6 Rolls</p>
              </div>
            </div>
            <div className="col-md-3 col-sm-3 col-xs-6 recipe-detail-component">
              <div className="col-md-4">
                <img src={servings} alt="recipe detail" />
              </div>
              <div className="col-md-8">
                <em>Servings</em>
                <p className="detail-info">For Family</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <button onClick={props.logout} className="btn btn-outline-primary my-2 my-sm-0">Logout</button>
    </div>
  </nav>
);


Header.propTypes = {
  logout: PropTypes.func.isRequired,
};

export default Header;
