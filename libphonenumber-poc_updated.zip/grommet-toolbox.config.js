import path from 'path';

function getSettings(str) {
  var rootPath;
  if (str == "partner") {
    rootPath = "/psp-ui";
  } else {
    rootPath = "/ui";
  }
  
  return {
    dist: "resources",
    copyAssets: [
      'src/index.html'
      
    ],

    jsAssets: ['src/**/js/**/*.js'],
    mainJs: 'src/js/index.js',
    mainScss: 'src/scss/index.scss',
    devServerPort: 9000,
    eslintOverride: path.resolve(__dirname, 'customEslintrc'),
    publicPath: rootPath,
    devServer: {
      disableHostCheck: true
    },
    webpack: {
      output: {
        path: __dirname + "/resources"
      } 
    }
  };
}

export default {
  partnerPortalSettings: getSettings("partner"),
  customerPortalSettings: getSettings("customer"),
  evalPortalSettings: getSettings("eval")
};