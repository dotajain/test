import gulp from 'gulp';
import grommetToolbox from 'grommet-toolbox';
import opts from './grommet-toolbox.config';

//determine which portal to build
if (process.argv.indexOf("-customer") >= 0) { //builds customer (cwp) portal
  grommetToolbox(gulp, opts.customerPortalSettings);
} else if (process.argv.indexOf("-eval") >= 0) { //builds eval portal
  grommetToolbox(gulp, opts.evalPortalSettings);
} else if (process.argv.indexOf("-partner") >= 0) { //-partner (essm) is the default
  grommetToolbox(gulp, opts.partnerPortalSettings);
} else {
  grommetToolbox(gulp, opts.customerPortalSettings);
}

/* NON-GROMMET GULP TASKS */

var fs = require('fs'),
  bump = require('gulp-bump'),
  jsoncombine = require('gulp-jsoncombine'),
  semver = require('semver');

var getPackageJson = function () {
  return JSON.parse(fs.readFileSync('./package.json', 'utf8'));
};

gulp.task('bump-patch', function () {
  var pkg = getPackageJson();
  var newVer = semver.inc(pkg.version, 'patch');

  return gulp.src('./package.json')
    .pipe(bump({
      version: newVer
    }))
    .pipe(gulp.dest('./'));
});

gulp.task('bump-minor', function () {
  var pkg = getPackageJson();
  var newVer = semver.inc(pkg.version, 'minor');

  return gulp.src('./package.json')
    .pipe(bump({
      version: newVer
    }))
    .pipe(gulp.dest('./'));
});

gulp.task('bump-major', function () {
  var pkg = getPackageJson();
  var newVer = semver.inc(pkg.version, 'major');

  return gulp.src('./package.json')
    .pipe(bump({
      version: newVer
    }))
    .pipe(gulp.dest('./'));
});

// pulls libraries from NPM and places them in the src folder - only has to be done occasionally
gulp.task('build', function () {
  gulp.run('bump-patch');
});

gulp.task('localize', function () {
  return gulp.src('./src/data/dictionaries/*.json')
    .pipe(jsoncombine("dictionary.json", function (data) {

      var keys = [];
      var returnObj = {};

      for (var key in data) {
        // a separate key is returned per file and must be parsed later
        keys.push(key);
      }

      for (var i = 0; i < keys.length; i++) {
        var sectionName = keys[i];

        for (var dictKey in data[sectionName]) {
          returnObj[dictKey] = data[sectionName][dictKey];
        }
      }

      return new Buffer(JSON.stringify(returnObj));
    }))
    .pipe(gulp.dest("./src/data"));
});

gulp.task('dev-localize', function () {
  gulp.run('localize');
  gulp.run('dev');
});

gulp.task('dist-localize', function () {
  gulp.run('localize');
  gulp.run('dist');
});
