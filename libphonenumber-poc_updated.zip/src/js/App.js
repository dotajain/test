//framework imports
import React, { Component } from 'react';
import App from 'grommet/components/App';
import Box from 'grommet/components/Box';
import Header from 'grommet/components/Header';
import Title from 'grommet/components/Title';


import TelInput from './TelInput';

export default class Layout extends Component {
  constructor() {
    super();
    this._onPhoneNumberBlur = this._onPhoneNumberBlur.bind(this);
    this.state = {
      phoneNumber: ''
    };
  }
  componentWillMount() {
    this.setState({ phoneNumber: userData.phoneNumber });
  }

  _onPhoneNumberBlur(value) {
    this.setState({ phoneNumber: value });
  }

  render() {
    return (
      <div id="everything" className="everything">
        <div id="content">
          <div id="header" className="header"/>
          <div id="body" className="body">
            <App centered={false} inline={true}>
              <Box pad="small">
                <Header>
                  <Title>libphonenumber-js IE 11 issue POC</Title>
                </Header>
              </Box>
              <Box pad="large" size="medium">
                <TelInput 
                  label="Phone Number"
                  error="false"
                  country="US"
                  onBlur={this._onPhoneNumberBlur}
                  onChange={this._onPhoneNumberBlur}
                  isRequired
                  value={this.state.phoneNumber}
                />
              </Box>
            </App>
          </div>
        </div>
      </div>
    );
  }
}


const userData = {"securityQuestion1":"3","securityAnswer1":"test","securityQuestion2":"2","securityAnswer2":"test","sessionToken":null,"hppId":null,"companyName":"HPE","crsID":"","vatID":"","contactByEmail":"Y","contactByPhone":"Y","emailAddress":"anshu@gostellar.co","password":null,"confirmPassword":null,"firstName":"Anshu","lastName":"Rath","languageCode":"en","addressLine1":"1234","addressLine2":"Main","city":"Santa Monica","state":"ottawa","zipCode":"90404 AG","phoneNumber":"+50622123456","vatRequired":false,"newUser":false,"isGroupMember":false,"groupId":"","userGroupRole":null,"country":"CR","uIDUser":false};
