import React, { Component } from 'react';
import { NavLink  } from 'react-router-dom';
import _ from 'lodash';

import request from 'superagent';

import Header from '../Header';
import HeaderNav from '../Header/HeaderNav';
// var stringify = require('json-stringify-pretty-compact');

const VISIONURL = 'https://westus.api.cognitive.microsoft.com/vision/v1.0/ocr?language=unk&detectOrientation=true&subscription-key=2dfb35b7ba6d45b187b01388ee0fb116';

class Ocr extends Component {
  constructor() {
    super();
    this.state = {
      imageUrl: '',
      res: '',
      insurance: true,
    };
  }

  componentWillMount() {
    this.setState({ imageUrl: insuranceImage[0].url  }, () => {
      this.callApi();
    });
  }

  callApi = () => {
    this.setState({ loading: true });
    if(this.state.imageUrl) {
      const data = {
        'url': this.state.imageUrl,
      };
      request
      .post(VISIONURL)
      .send(data)
      .set('accept', 'json')
      .end((err, res) => {
        if(res) {
          this.setState({ res: res.body, loading: false });
        }
      });
    }
  } 

  _handleOnChange = url => {
    this.setState({ imageUrl: url }, () => {
      this.callApi();
    });
  }
  
  _convertPercentage = value => {
    return Math.floor(value * 100);
  }

  _onHealthChange = () => {
    this.setState({ health: true, fedex: false, insurance: false, banking: false, imageUrl: healthImages[0].url }, () => {
      this.callApi();
    });
  }
  // _onFedexChange = () => {
  //   this.setState({ health: false, fedex: true, insurance: false, banking: false, imageUrl: fedexImages[0].url }, () => {
  //     this.callApi();
  //   });
  // }
  _onInsuranceChange = () => {
    this.setState({ health: false, fedex: false, insurance: true, banking: false, imageUrl: insuranceImage[0].url }, () => {
      this.callApi();
    });
  }

  _onBankingChange = () => {
    this.setState({ health: false, fedex: false, insurance: false, banking: true, imageUrl: bankingImage[0].url }, () => {
      this.callApi();
    });
  }

  render () {
    let bgImage;
    if(this.state.imageUrl) {
      bgImage = {
        backgroundImage: `url(${this.state.imageUrl})`,
      };
    }
    
    let resultDAta = <div className="no-data">Add image to view data.</div>;

    if(this.state.res) {
      const ocrData = _.map(this.state.res.regions, (region) => {
        const regions = _.map(region.lines, line => {
          const lines = _.map(line.words, (word, i) => <span className="ocr-text" key={i}>{word.text}</span>);
          return <div className="ocr-lines">{lines}</div>;
        });
        return <div className="ocr-region">{regions}</div>;
      });

      resultDAta = ocrData;
    }


    


    if(this.state.loading) {
      resultDAta = (
        <div className="loading">loading...</div>
      );
    }

    let tabData;

    if(this.state.insurance) {
      tabData = _.map(insuranceImage, (image,i) => {
        return (
          <div className="image" key={i}>
            <button className={this.state.imageUrl === image.url ? 'active' : ' '} onClick={() => this._handleOnChange(image.url)}>
              <div className="image--bgImage" style={{
                backgroundImage: `url(${image.url})`,
              }} />
            </button>
          </div>
        );
      });
    } else if(this.state.banking) {
      tabData = _.map(bankingImage, (image,i) => {
        return (
          <div className="image" key={i}>
            <button className={this.state.imageUrl === image.url ? 'active' : ' '} onClick={() => this._handleOnChange(image.url)}>
              <div className="image--bgImage" style={{
                backgroundImage: `url(${image.url})`,
              }} />
            </button>
          </div>
        );
      });
    } else if(this.state.health) {
      tabData = _.map(healthImages, (image,i) => {
        return (
          <div className="image" key={i}>
            <button className={this.state.imageUrl === image.url ? 'active' : ' '} onClick={() => this._handleOnChange(image.url)}>
              <div className="image--bgImage" style={{
                backgroundImage: `url(${image.url})`,
              }} />
            </button>
          </div>
        );
      });
    }

    return (
      <div>
        <HeaderNav />
        <div className="main">
          <Header
            banner="https://azurecomcdn.azureedge.net/cvt-76642664b6c62b753883c6f741dde50efd7c94e27e9174a12bea148cd8b19334/less/images/section/colleagues-discussing.jpg"
            title="Image Recognisation API"
            subtitle="Extract rich information from images to categorise and process visual data – and machine-assisted moderation of images to help curate your services."
          />
          <div className="subheader">
            <nav className="nav">
              <NavLink exact activeClassName="active" className="nav-link" to="/vision">
                Analyse an image
              </NavLink>
              <NavLink exact activeClassName="active" className="nav-link" to="/ocr">
                OCR Image Recognisation API
              </NavLink>
            </nav>
          </div>
          <section>
            <div className="container-fluid">
              <div className="section-header">
                <h2>Read text in images</h2>
                <p>Optical character recognition (OCR) detects text in an image and extract the recognised words into a machine-readable character stream. Analyse images to detect embedded text, generate character streams and enable searching. Take photos of text instead of copying to save time and effort.</p>
              </div>
              <div className="demo--screen">
                <div className="row">
                  <div className="col-md-6">
                    <div className="card border-primary">
                      <div className="card-header">
                        <div className="nav nav-tabs card-header-tabs">
                          <li className="nav-item">
                            <button onClick={this._onInsuranceChange} className={this.state.insurance ? 'nav-link active' : 'nav-link'}>Insurance</button>
                          </li>
                          <li className="nav-item">
                            <button onClick={this._onBankingChange} className={this.state.banking ? 'nav-link active' : 'nav-link'}>Banking</button>
                          </li>
                          <li className="nav-item">
                            <button className={this.state.health ? 'nav-link active' : 'nav-link'} onClick={this._onHealthChange} >Healthcare</button>
                          </li>
                        </div>
                      </div>
                      <div className="card-body">
                        <div className="demo-image-list">
                          {tabData}
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="image--container">
                      <div className="image" style={bgImage} />
                    </div>
                    <div className="response--container">
                      <div className="demo-img-results">
                        {resultDAta}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    );
  }
}
export default Ocr;

const healthImages = [
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/health_ocr_1.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/health_ocr_10.jpeg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/health_ocr_11.jpeg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/health_ocr_12.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/health_ocr_13.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/health_ocr_14.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/health_ocr_15.jpeg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/health_ocr_16.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/health_ocr_2.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/health_ocr_3.jpeg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/health_ocr_4.jpeg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/health_ocr_5.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/health_ocr_6.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/health_ocr_7.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/health_ocr_8.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/health_ocr_9.jpg',
  },
];


const insuranceImage = [
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/insurance_ocr_1.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/insurance_ocr_2.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/insurance_ocr_3.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/insurance_ocr_4.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/insurance_ocr_5.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/insurance_ocr_6.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/insurance_ocr_7.jpg',
  },
];

const bankingImage = [
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/banking_ocr_1.png',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/banking_ocr_10.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/banking_ocr_11.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/banking_ocr_12.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/banking_ocr_13.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/banking_ocr_14.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/banking_ocr_2.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/banking_ocr_3.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/banking_ocr_4.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/banking_ocr_5.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/banking_ocr_6.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/banking_ocr_7.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/banking_ocr_8.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/banking_ocr_9.jpg',
  },
  

];