import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Route, withRouter } from 'react-router-dom';
import Async from 'react-code-splitting';

const Home = () => <Async load={import('./Home')} />;
const Vision = () => <Async load={import('./Vision')} />;
const Ocr = () => <Async load={import('./Ocr')} />;

const App = ({ ...props }) => (
  <div id="react">
    <Route exact path="/" component={Home} {...props} />
    <Route path="/vision" component={Vision} {...props} />
    <Route path="/ocr" component={Ocr} {...props} />
  </div>
);

App.propTypes = {
  user: PropTypes.shape({}).isRequired,
};

export default withRouter(connect(state => ({ user: state.user }))(App));
