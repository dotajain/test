import React from 'react';
import {Link, NavLink  } from 'react-router-dom';

import Logo from '../../assets/images/syntel.png';

const HeaderNav = () => (
  <header className="navbar navbar-expand navbar-dark flex-column flex-md-row bd-navbar">
    <Link className="navbar-brand mr-0 mr-md-2" to="/"><img src={Logo} alt="syntel" /></Link>
    <div className="navbar-nav-scroll">
      <div className="navbar-nav bd-navbar-nav flex-row">
        <NavLink exact activeClassName="active" className="nav-link" to="/">
          Home
        </NavLink>
        <NavLink  activeClassName="active" className="nav-link" to="/vision">
          Image Recognisation API
        </NavLink>
        <NavLink  activeClassName="active" className="nav-link" to="/ocr">
          Read text in images
        </NavLink>
      </div>
    </div>
  </header>
);

// HeaderNav.propTypes = {
//   title: PropTypes.string,
// };

export default HeaderNav;
