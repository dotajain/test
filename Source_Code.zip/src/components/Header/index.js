import React from 'react';
import PropTypes from 'prop-types';

const Header = ({ ...props }) => {
  let bgStyle;
  if(props.banner) {
    bgStyle = {
      backgroundImage: `url(${props.banner})`,
    };
  }
  return (
    <div className="az-banner">
      <div className="az-banner--image" style={bgStyle} />
      <div className="az-banner--body">
        <div className="container-fluid">
          <h1>{props.title}</h1>
          <p>{props.subtitle}</p>
        </div>
      </div>
    </div>
  );
};

Header.propTypes = {
  banner: PropTypes.string,
  title: PropTypes.string,
  subtitle: PropTypes.string,
};

export default Header;
