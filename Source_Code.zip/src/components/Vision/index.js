import React, { Component } from 'react';
import { NavLink  } from 'react-router-dom';
import _ from 'lodash';

import request from 'superagent';

import Header from '../Header';
import HeaderNav from '../Header/HeaderNav';
// var stringify = require('json-stringify-pretty-compact');

const VISIONURL = 'https://westus.api.cognitive.microsoft.com/vision/v1.0/analyze?visualFeatures=Categories,Faces,ImageType,Color,Adult,Description,Tags&subscription-key=2dfb35b7ba6d45b187b01388ee0fb116';

class Vision extends Component {
  constructor() {
    super();
    this.state = {
      imageUrl: '',
      res: '',
      insurance: true,
    };
  }

  componentWillMount() {
    this.setState({ imageUrl: insuranceImage[0].url  }, () => {
      this.callApi();
    });
  }

  callApi = () => {
    this.setState({ loading: true });
    if(this.state.imageUrl) {
      const data = {
        'url': this.state.imageUrl,
      };
      request
      .post(VISIONURL)
      .send(data)
      .set('accept', 'json')
      .end((err, res) => {
        if(res) {
          this.setState({ res: res.body, loading: false });
        }
      });
    }
  } 

  _handleOnChange = url => {
    this.setState({ imageUrl: url }, () => {
      this.callApi();
    });
  }
  
  _convertPercentage = value => {
    return Math.floor(value * 100);
  }

  _onHealthChange = () => {
    this.setState({ health: true, fedex: false, insurance: false, banking: false, imageUrl: healthImages[0].url }, () => {
      this.callApi();
    });
  }
  // _onFedexChange = () => {
  //   this.setState({ health: false, fedex: true, insurance: false, banking: false, imageUrl: fedexImages[0].url }, () => {
  //     this.callApi();
  //   });
  // }
  _onInsuranceChange = () => {
    this.setState({ health: false, fedex: false, insurance: true, banking: false, imageUrl: insuranceImage[0].url }, () => {
      this.callApi();
    });
  }

  _onBankingChange = () => {
    this.setState({ health: false, fedex: false, insurance: false, banking: true, imageUrl: bankingImage[0].url }, () => {
      this.callApi();
    });
  }

  render () {
    let bgImage;
    if(this.state.imageUrl) {
      bgImage = {
        backgroundImage: `url(${this.state.imageUrl})`,
      };
    }
    
    let resultDAta = <div className="no-data">Add image to view data.</div>;

    if(this.state.res) {
      const badge = _.map(this.state.res.tags, (tag, i) => <span key={i} className="badge">{tag.name} <span className="confidence">{this._convertPercentage(tag.confidence)}%</span></span>);
      const dTags = _.map(this.state.res.description.tags, (tag, i) => <span key={i} className="badge">{tag}</span>);

      resultDAta = (
        <table className="table">
          <tbody>
            <tr>
              <th width="30%">Score</th>
              <td>{this.state.res.categories[0].score}</td>
            </tr>
            <tr>
              <th>Tags</th>
              <td><div className="bages">{badge}</div></td>
            </tr>
            <tr>
              <th>Description Tags</th>
              <td><div className="dtags">{dTags}</div></td>
            </tr>
            <tr>
              <th>Description Captions</th>
              <td>{this.state.res.description.captions[0].text} <span className="confidence">{this._convertPercentage(this.state.res.description.captions[0].confidence)}%</span></td>
            </tr>
          </tbody>
        </table>
      );
    }

    if(this.state.loading) {
      resultDAta = (
        <div className="loading">loading...</div>
      );
    }

    let tabData;

    if(this.state.insurance) {
      tabData = _.map(insuranceImage, (image,i) => {
        return (
          <div className="image" key={i}>
            <button className={this.state.imageUrl === image.url ? 'active' : ' '} onClick={() => this._handleOnChange(image.url)}>
              <div className="image--bgImage" style={{
                backgroundImage: `url(${image.url})`,
              }} />
            </button>
          </div>
        );
      });
    } else if(this.state.banking) {
      tabData = _.map(bankingImage, (image,i) => {
        return (
          <div className="image" key={i}>
            <button className={this.state.imageUrl === image.url ? 'active' : ' '} onClick={() => this._handleOnChange(image.url)}>
              <div className="image--bgImage" style={{
                backgroundImage: `url(${image.url})`,
              }} />
            </button>
          </div>
        );
      });
    } else if(this.state.health) {
      tabData = _.map(healthImages, (image,i) => {
        return (
          <div className="image" key={i}>
            <button className={this.state.imageUrl === image.url ? 'active' : ' '} onClick={() => this._handleOnChange(image.url)}>
              <div className="image--bgImage" style={{
                backgroundImage: `url(${image.url})`,
              }} />
            </button>
          </div>
        );
      });
    }

    return (
      <div>
        <HeaderNav />
        <div className="main">
          <Header
            banner="https://azurecomcdn.azureedge.net/cvt-76642664b6c62b753883c6f741dde50efd7c94e27e9174a12bea148cd8b19334/less/images/section/colleagues-discussing.jpg"
            title="Image Recognisation API"
            subtitle="Extract rich information from images to categorise and process visual data – and machine-assisted moderation of images to help curate your services."
          />
          <div className="subheader">
            <nav className="nav">
              <NavLink exact activeClassName="active" className="nav-link" to="/vision">
                Analyse an image
              </NavLink>
              <NavLink  activeClassName="active" className="nav-link" to="/ocr">
                OCR Image Recognisation API
              </NavLink>
            </nav>
          </div>
          <section>
            <div className="container-fluid">
              <div className="section-header">
                <h2>Analyse an image</h2>
                <p>This feature returns information about visual content found in an image. Use tagging, descriptions and domain-specific models to identify content and label it with confidence. Apply the adult/racy settings to enable automated restriction of adult content. Identify image types and color schemes in pictures.</p>
              </div>
              <div className="demo--screen">
                <div className="row">
                  <div className="col-md-6">
                    <div className="card border-primary">
                      <div className="card-header">
                        <div className="nav nav-tabs card-header-tabs">
                          <li className="nav-item">
                            <button onClick={this._onInsuranceChange} className={this.state.insurance ? 'nav-link active' : 'nav-link'}>Insurance</button>
                          </li>
                          <li className="nav-item">
                            <button onClick={this._onBankingChange} className={this.state.banking ? 'nav-link active' : 'nav-link'}>Banking</button>
                          </li>
                          <li className="nav-item">
                            <button className={this.state.health ? 'nav-link active' : 'nav-link'} onClick={this._onHealthChange} >Healthcare</button>
                          </li>
                        </div>
                      </div>
                      <div className="card-body">
                        <div className="demo-image-list">
                          {tabData}
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="image--container">
                      <div className="image" style={bgImage} />
                    </div>
                    <div className="response--container">
                      <div className="demo-img-results">
                        {resultDAta}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    );
  }
}

export default Vision;

const healthImages = [
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/health_1.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/health_10.jpeg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/health_11.jpeg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/health_12.jpeg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/health_13.jpeg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/health_14.jpeg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/health_15.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/health_2.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/health_3.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/health_4.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/health_5.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/health_6.jpeg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/health_7.jpeg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/health_8.jpeg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/health_9.jpeg',
  },
];


const insuranceImage = [
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/insurance_1.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/insurance_10.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/insurance_11.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/insurance_12.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/insurance_13.png',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/insurance_14.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/insurance_15.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/insurance_16.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/insurance_2.png',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/insurance_3.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/insurance_4.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/insurance_5.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/insurance_6.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/insurance_8.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/insurance_9.jpg',
  },
];

const bankingImage = [
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/banking_1.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/banking_2.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/banking_3.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/banking_4.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/banking_5.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/banking_6.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/banking_7.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/banking_8.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/banking_9.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/banking_10.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/banking_11.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/banking_12.jpg',
  },
  {
    url: 'https://atomcognitive.blob.core.windows.net/cognitiveatom/banking_13.jpg',
  },
];


// const fedexImages = [
//   {
//     url: 'http://www.perfectdaydiary.com/wordpress/wp-content/uploads/2014/09/Marriage-proposal-750x400.jpg',
//   },
//   {
//     url: 'https://o.aolcdn.com/images/dims3/GLOB/legacy_thumbnail/630x315/format/jpg/quality/85/http%3A%2F%2Fi.huffpost.com%2Fgen%2F4469732%2Fimages%2Fn-TRAVELLER-628x314.jpg',
//   },
//   {
//     url: 'https://media.gettyimages.com/photos/basketball-player-in-wheelchair-picture-id482783165',
//   },
// ];
