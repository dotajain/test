const API = 'http://localhost:3344';

export const CUSTOMERS = `${API}/customer`;
export const OFFER = `${API}/offers`;
export const LOGIN = `${API}/login`;
export const LOGIN_WITH_TOKEN = `${API}/token`;
