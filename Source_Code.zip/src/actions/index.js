import { actionTypes as types, urls } from '../constants';
import { get } from '../helpers';

export const login = () => dispatch => {
  dispatch({ type: types.LOGIN_REQUEST });
  dispatch({ type: types.LOGIN_SUCCESS,
    data: {
      token: 'QpwL5tke4Pnpja7X',
    } });
};
