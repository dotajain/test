
(function($){
    "use strict"
    var APP = {};

     /*--------------------
        * Header Class
    ----------------------*/
    APP.HeaderSticky = function(){
        $(".navbar-toggler").on("click", function(a) {
            a.preventDefault(), $(".navbar").addClass("fixed-header")
        });
    }

    /*--------------------
        * Menu Close
    ----------------------*/
    APP.MenuClose = function(){
      $('.navbar-nav .nav-link').on('click', function() {
       var toggle = $('.navbar-toggler').is(':visible');
       if (toggle) {
         $('.navbar-collapse').collapse('hide');
       }
      });
    }

    /*--------------------
        * Header height
    ----------------------*/

    APP.HeaderHeight = function(){
    var HHeight = $('.header-height .fixed-header-bar').height()
      $('header').height(HHeight);  
    }

    // /*--------------------
    //     * Smooth Scroll
    // ----------------------*/
    // APP.HeaderScroll = function(){
    //     $('header a[href*="#"]:not([href="#"])').on('click', function() {
    //         if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') || location.hostname == this.hostname) {
    //           var target = $(this.hash);
    //               target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
    //               if (target.length) {
    //                 $('html,body').animate({
    //                   scrollTop: target.offset().top - 65,
    //                   }, 1000);
    //                   return false;
    //               }
    //         }
    //     });
    // }

    /*--------------------
        * Header Fixed
    ----------------------*/
    APP.HeaderFixed = function(){
        if ($(window).scrollTop() >= 60) {
           $('.navbar').addClass('fixed-header');
           $('header').addClass('fixed-header-top');
        }
        else {
           $('.navbar').removeClass('fixed-header');
           $('header').removeClass('fixed-header-top');
        }
    }    

    
    /*--------------------
    * owl Slider
    ----------------------*/
    APP.BlogSlider = function(){
      var testimonials_slider = $('#ss-slider-single');
        testimonials_slider.owlCarousel({
            loop: true,
            margin: 0,
            nav:true,
            navText:["<i class='fas fa-angle-left'></i>","<i class='fas fa-angle-right'></i>"],
            dots:false,
            responsive: {
              0: {
                items: 1
              },
              768: {
                items: 2
              },
              991: {
                items: 3
              },
              1140: {
                items: 6
              }
            }
        });
    }

    // 
    APP.ClientSlider = function(){
      var testimonials_slider = $('#client-slider-single');
        testimonials_slider.owlCarousel({
            loop: true,
            margin: 0,
            nav:false,
            dots:false,
            responsive: {
              0: {
                items: 1
              },
              600: {
                items: 1
              },
              768: {
                items: 2
              },
              991: {
                items: 3
              },
              1140: {
                items: 3
              }
            }
        });
    }
    
    // Window on Load
    $(window).on("load", function(){
      APP.HeaderHeight();
    //   APP.WebLoad();
    });

    $(document).on("ready", function(){
        APP.HeaderHeight(),
        APP.ClientSlider(),
        APP.MenuClose(),
        APP.BlogSlider(),
        // APP.HeaderScroll(),
        APP.HeaderSticky();
    });

    $(window).on("scroll", function(){
        APP.HeaderFixed();
    });
    // Window on Resize
    $(window).on("resize", function(){
      APP.HeaderHeight();
    });

})(jQuery);

