import React, { Component } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import Dropzone from 'react-dropzone';
import request from 'superagent';
import MainScreen from './partial/MainScreen';
import FridgeScreen from './partial/FridgeScreen';
import CameraScreen from './partial/CameraScreen';
import Result from './partial/Result';
import bg1 from '../../assets/images/egg-yes.jpg';

const PREDICTION_KEY = '11abea3320d04833af3305ab902b93f6';
const CUSTOM_VISION_URL = 'https://southcentralus.api.cognitive.microsoft.com/customvision/v1.1/Prediction/eb89a26a-f2cc-40df-843d-70d34a46fb6b/image?iterationId=b0054e5b-c203-4830-8f6d-80a7dc03888c';
const CUSTOM_VISION_URL_EGG ='https://southcentralus.api.cognitive.microsoft.com/customvision/v1.1/Prediction/ae66663b-6458-4fe7-ad1b-c0dddf4af434/image?iterationId=eceefd06-8d43-413c-ac0b-0c1e124a6033';

// https://southcentralus.api.cognitive.microsoft.com/customvision/v1.0/Prediction/6db2e8a3-3872-4847-bb93-5fb8e950d750/image?iterationId=006c4bb3-c8be-4fb2-83e5-f9d0c7612069
// Set Prediction-Key Header to : 11abea3320d04833af3305ab902b93f6
// Set Content-Type Header to : application/octet-stream
// Set Body to : <image file>

export default class HomePage extends Component {
  constructor() {
    super();
    this.onImageDrop = this.onImageDrop.bind(this);
    this._backtoFridgeScreen=this._backtoFridgeScreen.bind(this);
    this._BackToMainScreen=this._BackToMainScreen.bind(this);
    this._view=this._view.bind(this);
    this._cameraView=this._cameraView.bind(this);
    this._CameraAnalysis=this._CameraAnalysis.bind(this);
    this._callapi=this._callapi.bind(this);
    this.state = {
      uploadedFile: '',
      tags: '',
      pageId:'1',
      pageItem:'',
      imagesArray: [],
     

    };
  }
  componentWillMount() {
    this.setState({ imagesArray: initialImages });
  }

  onImageDrop(files) {
    this.setState({ tags: '' });
    this.setState({
      uploadedFile: files[0],
      name: files[0].name,
    });
    this.handleImageUpload(files[0]);
  }

  _BackToMainScreen(){
    this.setState({ pageId:'1' });
  }
  _view(){
    console.log('heelo');
    this.setState({ pageId:'2', pageItem:'2' });
  }
  _callapi(){
  
  }
  _backtoFridgeScreen(){
    this.setState({ pageId:'2' });
  }

  _cameraView(){
    
    this.setState({ pageId:'3' });
  }

  _CameraAnalysis(){
    console.log('camera analysis');
   
    console.log(CUSTOM_VISION_URL_EGG);
    this.setState({ pageId:'4' });
  }

  handleImageUpload = file => {
    const upload = request.post(CUSTOM_VISION_URL)
    .set({ 'Prediction-Key': PREDICTION_KEY, Accept: 'application/json' })
    .field('file', file);
    upload.end((err, response) => {
      if (err) {
        console.error(err);
      }
      if (response.status === 200) {
        this.setState({
          tags: response.body.Predictions,
        });
      }
    });
  }
  
  render() {
    
   
    let showImage;
    let pagedisplay;
    if(this.state.pageId){
      pagedisplay=<MainScreen View={this._view}/>;
    }
    if(this.state.pageId==2){
      pagedisplay=<FridgeScreen CameraView={this._cameraView} BackToMainScreen={this._BackToMainScreen}/>;
    }
    if(this.state.pageId==3){
      pagedisplay=<CameraScreen CameraAnalysis={this._CameraAnalysis} backtoFridgeScreen={this._backtoFridgeScreen} imagesArray={this.state.imagesArray}/>;
    }
    if(this.state.pageId==4){
      pagedisplay=<Result/>;
    }
    if (this.state.tags) {
      _.map(this.state.tags, item => {
        if(item.Tag === 'egg') {
          if(item.Probability < 0.8) {
            showImage = <div className="tagImage"><img src={bg1} alt="image"/> <span className="tag">Missing Egg</span></div>;
          }
        }
      });
     
     
      console.log(Dropzone);
      console.log(showImage);
      
    }
    
    return (
      <div>
        <div className="text-center logoutbutton">
          <button className="btn btn-outline-primary mb-3" onClick={this.props.logout}>Logout</button>
        </div>
     {pagedisplay}
      </div>
    );
  }
}

HomePage.propTypes = {
  
  logout: PropTypes.func.isRequired,
};



const initialImages = [
  {
    imgurl: 'https://hackthonblob.blob.core.windows.net/hackthon/1.jpg',
    name: 'name1',
  },
  {
    imgurl: 'https://hackthonblob.blob.core.windows.net/hackthon/2.jpg',
    name: 'name2',
  },
  {
    imgurl: 'https://hackthonblob.blob.core.windows.net/hackthon/3.jpg',
    name: 'name3',
  },
  {
    imgurl: 'https://hackthonblob.blob.core.windows.net/hackthon/4.jpg',
    name: 'name4',
  },
  {
    imgurl: 'https://hackthonblob.blob.core.windows.net/hackthon/5.jpg',
    name: 'name5',
  },
  {
    imgurl: 'https://hackthonblob.blob.core.windows.net/hackthon/6.jpg',
    name: 'name6',
  },
  {
    imgurl: 'https://hackthonblob.blob.core.windows.net/hackthon/7.jpg',
    name: 'name7',
  },
  {
    imgurl: 'https://hackthonblob.blob.core.windows.net/hackthon/8.jpg',
    name: 'name8',
  },
  {
    imgurl: 'https://hackthonblob.blob.core.windows.net/hackthon/9.jpg',
    name: 'name9',
  },
  {
    imgurl: 'https://hackthonblob.blob.core.windows.net/hackthon/10.jpg',
    name: 'name10',
  },
  {
    imgurl: 'https://hackthonblob.blob.core.windows.net/hackthon/11.jpg',
    name: 'name11',
  },
  {
    imgurl: 'https://hackthonblob.blob.core.windows.net/hackthon/12.jpg',
    name: 'name12',
  },
  {
    imgurl: 'https://hackthonblob.blob.core.windows.net/hackthon/13.jpg',
    name: 'name13',
  },
  {
    imgurl: 'https://hackthonblob.blob.core.windows.net/hackthon/14.jpg',
    name: 'name14',
  },
  {
    imgurl: 'https://hackthonblob.blob.core.windows.net/hackthon/15.jpg',
    name: 'name15',
  },
  {
    imgurl: 'https://hackthonblob.blob.core.windows.net/hackthon/16.jpg',
    name: 'name16',
  },
  {
    imgurl: 'https://hackthonblob.blob.core.windows.net/hackthon/17.jpg',
    name: 'name17',
  },
  {
    imgurl: 'https://hackthonblob.blob.core.windows.net/hackthon/18.jpg',
    name: 'name18',
  },
  {
    imgurl: 'https://hackthonblob.blob.core.windows.net/hackthon/19.jpg',
    name: 'name19',
  },
  {
    imgurl: 'https://hackthonblob.blob.core.windows.net/hackthon/20.jpg',
    name: 'name20',
  },
  
];