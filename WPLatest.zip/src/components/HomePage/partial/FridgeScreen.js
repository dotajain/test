import React from  'react';
import PropTypes from 'prop-types';
import bg1 from '../../../assets/images/sm.jpeg';

const FridgeScreen =({...props}) =>(
  <div className="fridgealign">
  <div className="fridgeimage">
    <img src={bg1} alt="image"/>
    
  </div>
  <button className="fridge btnsize" onClick={props.CameraView}>WHIRLPOOL Camera VIEW NOW</button> 
    <button className="fridge btnsize" onClick={props.BackToMainScreen}>Back To Main Screen </button>
    </div>
);
FridgeScreen.propTypes={
  CameraView: PropTypes.func,
  BackToMainScreen:PropTypes.func,
};
export default FridgeScreen;