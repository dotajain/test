import React from  'react';
import PropTypes from 'prop-types';
import _ from 'lodash';

const CameraScreen =({...props}) =>{

  const imageList = _.map(props.imagesArray, (item, i) => {
    return (
      <div className=" col-sm-3" key={i}>
          <div className="card">
         <div className="card-body">
           <h4 className="card-title">Camera{i}</h4>
           <img className="card-img-top" src={item.imgurl} alt={i}/>
        </div>
      </div>
      </div>
    );
  });
  return(
<div>
<div className="card-group">
 {imageList}
</div>   
 

      <div className="text-center col-sm-12 mt-5 mb-5"> 
  
   <button className="fridge btnsize" onClick={props.CameraAnalysis}> Camera Analysis</button> 
      <button className="fridge btnsize" onClick={props.backtoFridgeScreen}>backtoFridgeScreen</button>
      </div>
    </div>

  );
};
CameraScreen.propTypes={
  CameraAnalysis: PropTypes.func,
  backtoFridgeScreen:PropTypes.func,
  imagesArray:PropTypes.array,
};

export default CameraScreen;