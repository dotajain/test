import React from  'react';
import PropTypes from 'prop-types';
import cake from '../../../assets/images/cake.jpg';

const MainScreen =({...props}) =>(
  <div className="container-fluid ">
      <div className="row">
          <div className="col-md-4 col-lg-4 pad">
            <div className="d-flex flex-column cakecolor ">
                <img src={cake} alt="cake" className="img-thumbnail"/>
                <h1 className="bgcolor display-4">CHOCOLATE CAKE</h1>
                <p className="pbox">Moist,delicious chocolate cake for any celebration.Make the perfect cake with help from this recipe.</p>

            </div>
          </div>
          <div className="col-md-8 col-lg-8 ingredientsContainer ">
              <div className="d-flex flex-column ">
                  <h1 className="display-4 ingredients">INGREDIENTS</h1>
                  <div className="d-flex flex-row space">
                       <div className="d-flex flex-row space">
                       <span className="numberCircle"></span>
                            <h1 className="display-6 pad-left">sugar</h1>
                       </div>
                     <h1 className="display-6">2 cups</h1>
                 
                  </div>
                  <div className="d-flex flex-row space">
                       <div className="d-flex flex-row space">
                       <span className="numberCircle"></span>
                            <h1 className="display-6 pad-left">cocoa powder</h1>
                       </div>
                     <h1 className="display-6">3/4 cups</h1>
                 
                  </div>
                  <div className="d-flex flex-row space">
                       <div className="d-flex flex-row space">
                       <span className="numberCircle"></span>
                            <h1 className="display-6 pad-left">eggs</h1>
                       </div>
                     <h1 className="display-6">4 eggs</h1>
                 
                  </div>
                  <div className="d-flex flex-row space">
                       <div className="d-flex flex-row space">
                       <span className="numberCircle"></span>
                            <h1 className="display-6 pad-left">rice milk </h1>
                       </div>
                     <h1 className="display-6">1 cups</h1>
                 
                  </div>
                  <div className="d-flex flex-row space">
                       <div className="d-flex flex-row space">
                       <span className="numberCircle"></span>
                            <h1 className="display-6 pad-left">all-purpose flour</h1>
                       </div>
                     <h1 className="display-6">2 cups</h1>
                 
                  </div>
                  <div className="d-flex flex-row space">
                       <div className="d-flex flex-row space">
                       <span className="numberCircle"></span>
                            <h1 className="display-6 pad-left">baking soda</h1>
                       </div>
                     <h1 className="display-6">3/2 tsp</h1>
                 
                  </div>
                   <div className="d-flex flex-row space">
                       <div className="d-flex flex-row space">
                       <span className="numberCircle"></span>
                            <h1 className="display-6 pad-left">salt</h1>
                       </div>
                   <button className="fridge" onClick={props.View}>WHIRLPOOL FRIDGE VIEW NOW</button>
                 
                  </div>
              </div>
          </div>
        </div>

  </div>

);

MainScreen.propTypes={
  View: PropTypes.func,
};
export default MainScreen;