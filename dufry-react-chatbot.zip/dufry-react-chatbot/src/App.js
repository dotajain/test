import React, { Component } from 'react';
import { ThemeProvider } from 'styled-components';
import ChatBot from 'react-simple-chatbot';

import Logo from './Logo';
import RetailBotComponent from './RetailBotComponent';

const theme = {
  background: '#f5f8fb',
  headerBgColor: '#EF6C00',
  headerFontColor: '#fff',
  headerFontSize: '15px',
  botBubbleColor: '#EF6C00',
  botFontColor: '#fff',
  userBubbleColor: '#fff',
  userFontColor: '#4a4a4a',
  width: '100%',
};

class App extends Component {
  render() {
    return (
      <main className="bd-masthead" role="main">
        <div className="d-flex justify-content-around align-items-center">
          <div className="text-center">
            
            <Logo />
            <h1>ATOM Retail Bot Assistent</h1>
            <div className="text-left">
              <h2>Smart Shopping</h2>
              <p>
                How <strong>Artificial Intelligence</strong> is<br/>
                transformaing the retails conversation using<br/> 
                <strong>ATOM ChatBot</strong> for Retails. 
              </p>
            </div>
          </div>
          <div>
            <ThemeProvider theme={theme}>
              <ChatBot
                width="360px"
                hideHeader
                recognitionEnable              
                steps={[
                  {
                    id: '1',
                    message: 'Hello!, Welcome to the ATOM Retail Assistent, Do you need some help?',
                    trigger: 'search',
                  },
                  {
                    id: 'search',
                    user: true,
                    trigger: '3',
                  },
                  {
                    id: '3',
                    component: <RetailBotComponent />,
                    asMessage: true,
                    waitAction: true,
                    trigger: 'search',
                  },
                ]}
              />
            </ThemeProvider>
          </div>
        </div>
      </main>
    );
  }
}

export default App;
