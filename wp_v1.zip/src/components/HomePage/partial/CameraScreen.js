import React, { Component } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';

import request from 'superagent';

import CardIngredients from './CardIngredients';

const CUSTOM_VISION_URL = 'https://southcentralus.api.cognitive.microsoft.com/customvision/v1.1/Prediction/a77021fd-2f6b-4504-a1b6-8c2e5f3408db/url';
const PREDICTION_KEY = '11abea3320d04833af3305ab902b93f6';

class CameraScreen extends Component {
  constructor(props) {
    super(props);
    this._getCustomVisionTags = this._getCustomVisionTags.bind(this);
    this.fetchdata = this.fetchdata.bind(this);
    this.storeData = this.storeData.bind(this);
    this._ingredientsAnalyais = this._ingredientsAnalyais.bind(this);
    this._closeModal = this._closeModal.bind(this);

    this.state = {
      imagesArray: '',
      loading: false,
      data: [],
      loop: 0,
    };
  }

  componentWillMount() {
    this.setState({ imagesArray: this.props.imagesArray });
  }

  _getCustomVisionTags() {
    // const self = this;
    this.setState({ loading: true }, () => {
      this.fetchdata(this.state.loop);
    });
  }

  fetchdata(loop) {
    const self = this;
    const length = this.state.imagesArray.length;
    if (loop < length) {
      // this.setState({ loop: this.state.loop + 1 }, () => {
      request.post(CUSTOM_VISION_URL)
        .set({ 'Prediction-Key': PREDICTION_KEY, Accept: 'application/json' })
        .send({ 'Url': this.state.imagesArray[loop].url })
        .then(function (res) {
          setTimeout(function () {
            self.storeData(res.body);
          }, 2000);
        });
      // });
    } else {
      this.setState({ loading: false, analysis: true });
    }
  }

  storeData(data) {
    const imagesArray = this.state.imagesArray;
    imagesArray[this.state.loop].tags = data.Predictions;

    this.setState({
      imagesArray,
      loop: this.state.loop + 1,
    }, () => {
      this.fetchdata(this.state.loop);
    });
  }

  _ingredientsAnalyais() {
    this.setState({ ingredientAnalysis: true });
  }

  _closeModal() {
    this.setState({ ingredientAnalysis: false });
  }

  render() {
    const imageList = _.map(this.state.imagesArray, (item, i) => {
      let tags;

      if (item.tags) {
        tags = _.map(item.tags, (tag, e) => {
          var item;
          var percentValue = Math.floor(tag.Probability * 100);
          if (percentValue >= 90 && percentValue <= 100) {
            item = (<span className="badge badge-pill badge-primary green" key={e}>{tag.Tag} <span className="badge badge-light">{`${percentValue}%`}</span></span>);
          } else if (percentValue >= 70 && percentValue < 90) {
            item = (<span className="badge badge-pill badge-primary orange" key={e}>{tag.Tag} <span className="badge badge-light">{`${percentValue}%`}</span></span>);
          } else if (percentValue >= 50 && percentValue < 70) {
            item = (<span className="badge badge-pill badge-primary red" key={e}>{tag.Tag} <span className="badge badge-light">{`${percentValue}%`}</span></span>);
          }

          return item;
        }
        );
      }
      return (
        <div className="col-sm-3" key={i}>
          <div className="card bg-light">
            <div className="card-header"><div>Camera View</div> <span>{i + 1}</span></div>
            <div className="card-body">
              <img className="card-img-top" src={item.url} alt={i} />
            </div>
            <div className="card-footer">
              {tags ? tags : <span>No tags...</span>}
            </div>
          </div>
        </div>
      );
    });

    let loading;
    let analysisButton;
    if (this.state.loading) {
      loading = (
        <div className="page-loader">
          AI Food Recognition In Progress <br />
          <div className="loader">
            <svg version="1.1" id="Layer_1" x="0px" y="0px"
              width="24px" height="30px" viewBox="0 0 24 30" xmlSpace="preserve">
              <rect x="0" y="10" width="4" height="10" fill="#333" opacity="0.2">
                <animate attributeName="opacity" attributeType="XML" values="0.2; 1; .2" begin="0s" dur="0.6s" repeatCount="indefinite" />
                <animate attributeName="height" attributeType="XML" values="10; 20; 10" begin="0s" dur="0.6s" repeatCount="indefinite" />
                <animate attributeName="y" attributeType="XML" values="10; 5; 10" begin="0s" dur="0.6s" repeatCount="indefinite" />
              </rect>
              <rect x="8" y="10" width="4" height="10" fill="#333" opacity="0.2">
                <animate attributeName="opacity" attributeType="XML" values="0.2; 1; .2" begin="0.15s" dur="0.6s" repeatCount="indefinite" />
                <animate attributeName="height" attributeType="XML" values="10; 20; 10" begin="0.15s" dur="0.6s" repeatCount="indefinite" />
                <animate attributeName="y" attributeType="XML" values="10; 5; 10" begin="0.15s" dur="0.6s" repeatCount="indefinite" />
              </rect>
              <rect x="16" y="10" width="4" height="10" fill="#333" opacity="0.2">
                <animate attributeName="opacity" attributeType="XML" values="0.2; 1; .2" begin="0.3s" dur="0.6s" repeatCount="indefinite" />
                <animate attributeName="height" attributeType="XML" values="10; 20; 10" begin="0.3s" dur="0.6s" repeatCount="indefinite" />
                <animate attributeName="y" attributeType="XML" values="10; 5; 10" begin="0.3s" dur="0.6s" repeatCount="indefinite" />
              </rect>
            </svg>
          </div>
        </div>
      );

    }

    if (this.state.analysis) {
      analysisButton = (<button className="btn btn-secondary" onClick={this._ingredientsAnalyais}>
        Check Against Recipe Ingredients
    </button>);
    } else {
      analysisButton = (<button className="btn btn-primary" onClick={this._getCustomVisionTags}>
        Run AI Food Recognition Bot
    </button>);
    }

    let modal;

    if (this.state.ingredientAnalysis) {
      modal = (
        <div className="modal fade show">
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Matched Recipe Ingredients</h5>
                <button onClick={this._closeModal} className="close modal-close">&times;</button>
              </div>
              <div className="modal-body">
                <CardIngredients data={ingredientsData} />
              </div>
              <div className="modal-footer">
                <button className="btn btn-primary">Order now</button>
              </div>
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className="main-page camera-page">
        {loading}
        <div className="container-fluid">
          <div className="section-header no-image" />
          <div className="row">
            {imageList}
          </div>
        </div>

        <div className="main--footer">
          <button className="btn btn-outline-secondary back-button" onClick={this.props.backtoFridgeScreen}>
            Back
          </button>
          {analysisButton}
        </div>
        {modal}
      </div>
    );
  }
}

CameraScreen.propTypes = {
  CameraAnalysis: PropTypes.func,
  backtoFridgeScreen: PropTypes.func,
  imagesArray: PropTypes.array,
};

export default CameraScreen;

const ingredientsData = [
  {
    id: 0,
    name: 'Sugar (2 cups)',
    available: false,
  },
  {
    id: 1,
    name: 'Cocoa powder (3/4 cups)',
    available: true,
  },
  {
    id: 2,
    name: 'Eggs (4 eggs)',
    available: true,
  },
  {
    id: 3,
    name: 'Milk (1 cups)',
    available: true,
  },
  {
    id: 4,
    name: 'All-purpose flour (2 cups)',
    available: false,
  },
  {
    id: 5,
    name: 'Salt (1 tsp)',
    available: false,
  },
];