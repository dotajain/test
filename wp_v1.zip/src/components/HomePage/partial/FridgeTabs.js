import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';

import Tabs from './Tabs';
import TabPane from './TabPane';

const FridgeTabs = (props) => {
  return (
    <Tabs selected={props.firstSelect || 0}>
      {_.map(tabs, (tab, i) => <TabPane key={i} label={tab.name}>{tab.content}</TabPane>) } 
    </Tabs>
  );
};

FridgeTabs.propTypes = {
  firstSelect: PropTypes.number,
};



const tabs = [{ 
  name: 'Tab 1',
  content: 'Content for 1',
}, {
  name: 'Tab 2', 
  content: 'Content for 2',
  
}, {
  name: 'Tab 3',
  content: 'Content for 3',
}];

export default FridgeTabs; 
