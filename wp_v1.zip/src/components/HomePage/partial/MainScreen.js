import React from 'react';
import PropTypes from 'prop-types';
import CardIngredients from './CardIngredients';

// http://cakeart.thimpress.com/recipes/chocolate-crinkle-cookies/
const MainScreen = ({...props }) => (
  <div className="main-page">
    <header className="wp-header">
      <div className="container">
        <div className="row">
          <div className="col-md-12 text-center ">
            <h1>Time to Create your <br /> CHOCOLATE CAKE</h1>
            <p>Delicious, delightful and desirable chocolate cake for any celebration. <br/>Make your loved ones go crazy with this recipe.</p>
            <ul className="buttons">
              <li className="scrollToLink">
                <button onClick={props.launchDemoScreen} className="thm-btn" >Check Demos<i className="fa fa-arrow-circle-right"></i></button>
              </li>
            </ul>
            <div className="rev-scroll-btn"><span></span></div>
          </div>
        </div>
      </div>
    </header>
    <div className="cake-steps">
      <div className="cake-row">
        <div className="cake-shadow">
          <div className="row">
            <div className="col">
              <div className="cake-card">
                <div className="cake-card-wrapper">
                  <div className="cake-icon-left">
                    <div className="row">
                      <div className="icon col-md-4 col-sm-12 col-xs-4">
                        <img width="121" height="115" src="http://cakeart.thimpress.com/wp-content/uploads/2015/07/iconbox1.jpg" className="attachment-thumbnail size-thumbnail" alt="" />
                      </div>
                      <div className="content col-md-8 col-sm-12 col-xs-8">
                        <h3 className="title">Step 1</h3>
                        <div className="des"><strong>Ingredients</strong> – check the list of ingredients require for preparing Cake.</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col">
              <div className="cake-card">
                <div className="cake-card-wrapper">
                  <div className="cake-icon-left">
                    <div className="row">
                      <div className="icon col-md-4 col-sm-12 col-xs-4">
                        <img width="121" height="115" src="http://cakeart.thimpress.com/wp-content/uploads/2015/07/iconbox2.jpg" className="attachment-thumbnail size-thumbnail" alt="" />
                      </div>
                      <div className="content col-md-8 col-sm-12 col-xs-8">
                        <h3 className="title">Step 2</h3>
                        <div className="des"><strong>Select items</strong> – Confirm if those ingredients are present inside Refrigerator.</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col">
              <div className="cake-card">
                <div className="cake-card-wrapper">
                  <div className="cake-icon-left">
                    <div className="row">
                      <div className="icon col-md-4 col-sm-12 col-xs-4">
                        <img width="121" height="115" src="http://cakeart.thimpress.com/wp-content/uploads/2015/07/iconbox3.jpg" className="attachment-thumbnail size-thumbnail" alt="" />
                      </div>
                      <div className="content col-md-8 col-sm-12 col-xs-8">
                        <h3 className="title">Step 3</h3>
                        <div className="des"><strong>Recipes</strong> – Follow the instructions to savor the scrumptious Chocolate Cake.</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div className="section-header">
      <h3>Ingredients</h3>
      <div className="tm-table">
        <div className="line table-cell"></div>
        <img className="table-cell" src="http://cakeart.thimpress.com/wp-content/themes/cakeart//images/cupcake.png" alt="cupcake" title="Heading image" />
        <div className="line table-cell"></div>
      </div>
    </div>
    <div className="main-section container-fluid">
      <div className="row">
        <div className="col-md-8">
          <h2 className="main-section-title">INSTRUCTIONS</h2>
          <p>
            Everyone loves chocolate cake, and this chocolate cake recipe is a true classic.
          </p>
          <div className="steps">
            <div className="steps--items">
              <h3>Step 1</h3>
              <p>Preheat your oven to 350 F.</p>
            </div>
            <div className="steps--items">
              <h3>Step 2</h3>
              <p>
                Whisk together all-purpose flour, cocoa powder, baking soda, and salt. Add eggs one at a time, beating well after each addition. Add sugar, flour mixture and milk alternately in batches, beginning and ending with flour and mixing just until combined.
              </p>
            </div>
            <div className="steps--items">
              <h3>Step 3</h3>
              <p>
                Pour batter into cake pan and bake in middle of oven until springy to the touch and a tester inserted in center comes out clean, 55 minutes to 1 hour. Cool in pan 1 hour. Invert onto a rack, then turn right side up and dust with powdered sugar.
              </p>
            </div>
          </div>
        </div>
        <div className="col-md-4">
          <CardIngredients data={ingredientsData}/>
        </div>
      </div>
    </div>
    <div className="main--footer">
      <button className="btn btn-primary" onClick={props.View}>
        Analysis Fridge View
      </button>
    </div>
  </div>

);

MainScreen.propTypes = {
  View: PropTypes.func,
  launchDemoScreen: PropTypes.func,
};
export default MainScreen;

const ingredientsData = [
  {
    id: 0,
    name: 'Sugar (2 cups)',
    available: false,
  },
  {
    id: 1,
    name: 'Cocoa powder (3/4 cups)',
    available: false,
  },
  {
    id: 2,
    name: 'Eggs (4 eggs)',
    available: false,
  },
  {
    id: 3,
    name: 'Milk (1 cups)',
    available: false,
  },
  {
    id: 4,
    name: 'All-purpose flour (2 cups)',
    available: false,
  },
  {
    id: 5,
    name: 'Salt (1 tsp)',
    available: false,
  },
];