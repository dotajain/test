import React, { Component } from 'react';
import _ from 'lodash';
import PropTypes from 'prop-types';
import Dropzone from 'react-dropzone';
import request from 'superagent';
import MainScreen from './partial/MainScreen';
import FridgeScreen from './partial/FridgeScreen';
import CameraScreen from './partial/CameraScreen';
import Result from './partial/Result';
import bg1 from '../../assets/images/egg-yes.jpg';
import { connect } from 'react-redux';
import { getFridgeData } from '../../actions';
import Demo from '../Demo';

const PREDICTION_KEY = '11abea3320d04833af3305ab902b93f6';
const CUSTOM_VISION_URL = 'https://southcentralus.api.cognitive.microsoft.com/customvision/v1.1/Prediction/eb89a26a-f2cc-40df-843d-70d34a46fb6b/image?iterationId=b0054e5b-c203-4830-8f6d-80a7dc03888c';
const CUSTOM_VISION_URL_EGG ='https://southcentralus.api.cognitive.microsoft.com/customvision/v1.1/Prediction/ae66663b-6458-4fe7-ad1b-c0dddf4af434/image?iterationId=eceefd06-8d43-413c-ac0b-0c1e124a6033';

// https://southcentralus.api.cognitive.microsoft.com/customvision/v1.0/Prediction/6db2e8a3-3872-4847-bb93-5fb8e950d750/image?iterationId=006c4bb3-c8be-4fb2-83e5-f9d0c7612069
// Set Prediction-Key Header to : 11abea3320d04833af3305ab902b93f6
// Set Content-Type Header to : application/octet-stream
// Set Body to : <image file>

class HomePage extends Component {
  constructor(props) {
    super(props);
    this.onImageDrop = this.onImageDrop.bind(this);
    this._backtoFridgeScreen=this._backtoFridgeScreen.bind(this);
    this._BackToMainScreen=this._BackToMainScreen.bind(this);
    this._view=this._view.bind(this);
    this._cameraView=this._cameraView.bind(this);
    this._CameraAnalysis=this._CameraAnalysis.bind(this);
    this._callapi=this._callapi.bind(this);
    this._handleClick=this._handleClick.bind(this);
    this.launchDemoScreen=this.launchDemoScreen.bind(this);
    this.state = {
      uploadedFile: '',
      tags: '',
      pageId:'1',
      pageItem:'',
      imagesArray: [],
      activeImage: '',

    };
  }

  componentWillMount() {
    this.setState({ imagesArray: [] }, () => {
      this.props.getFridgeData();
    });
    
  }
  
  onImageDrop(files) {
    this.setState({ tags: '' });
    this.setState({
      uploadedFile: files[0],
      name: files[0].name,
    });
    this.handleImageUpload(files[0]);
  }

  _BackToMainScreen(){
    this.setState({ pageId:'1' });
  }
  _view(){
    this.setState({ pageId:'2', pageItem:'2' });
  }
  _callapi(){
  
  }
  _backtoFridgeScreen(){
    this.setState({ pageId:'2' });
  }

  _cameraView(data){
    console.log(data);
    this.setState({ pageId:'3', imagesArray: data });
  }

  _CameraAnalysis(){
    console.log('camera analysis');
   
    console.log(CUSTOM_VISION_URL_EGG);
    this.setState({ pageId:'4' });
  }

  _handleClick(activeImage) {
    this.setState({ activeImage });
  }

  handleImageUpload = file => {
    const upload = request.post(CUSTOM_VISION_URL)
    .set({ 'Prediction-Key': PREDICTION_KEY, Accept: 'application/json' })
    .field('file', file);
    upload.end((err, response) => {
      if (err) {
        console.error(err);
      }
      if (response.status === 200) {
        this.setState({
          tags: response.body.Predictions,
        });
      }
    });
  }
  
  componentWillReceiveProps(nextProps) {
    console.log(nextProps);
    if(nextProps.fridgeData) {
      this.setState({ activeImage: nextProps.fridgeData[0] });
    }
  }
  launchDemoScreen() {
    this.setState({ pageId: 5 });
  }

  render() {
    console.log(this.props);
    console.log(this.state);
    let showImage;
    let pagedisplay;
    if(this.state.pageId){
      pagedisplay=<MainScreen launchDemoScreen={this.launchDemoScreen} View={this._view}/>;
    }
    if(this.state.pageId==2){
      pagedisplay=<FridgeScreen handleClick={this._handleClick} activeImage={this.state.activeImage} fridgeData={this.props.fridgeData} CameraView={this._cameraView} BackToMainScreen={this._BackToMainScreen}/>;
    }
    if(this.state.pageId==3){
      pagedisplay=<CameraScreen CameraAnalysis={this._CameraAnalysis} backtoFridgeScreen={this._backtoFridgeScreen} imagesArray={this.state.imagesArray}/>;
    }
    if(this.state.pageId==4){
      pagedisplay=<Result/>;
    }
    if(this.state.pageId==5){
      pagedisplay = <Demo BackToMainScreen={this._BackToMainScreen} />;
    }
    if (this.state.tags) {
      _.map(this.state.tags, item => {
        if(item.Tag === 'egg') {
          if(item.Probability < 0.8) {
            showImage = <div className="tagImage"><img src={bg1} alt="image"/> <span className="tag">Missing Egg</span></div>;
          }
        }
      });
     
     
      console.log(Dropzone);
      console.log(showImage);
      
    }
    
    return (
      <div>
        {pagedisplay}
      </div>
    );
  }
}



HomePage.propTypes = {
  fridgeData: PropTypes.array,
  getFridgeData: PropTypes.func,
};
const mapStateToProps = state => ({ fridgeData: state.user.fridgeData });
export default connect(mapStateToProps, { getFridgeData })(HomePage);