import React from 'react';
import PropTypes from 'prop-types';

import demoUrl from '../../assets/images/Whirlpool_demo.mp4';

// http://cakeart.thimpress.com/recipes/chocolate-crinkle-cookies/
const Demo = ({ ...props }) => (
  <div className="main-page demopage">
    <video width="320" height="240" controls>
      <source src={demoUrl} type="video/mp4" />
      Your browser does not support the video tag.
		</video>
    <div className="main--footer">
      <button className="btn btn-primary" onClick={props.BackToMainScreen}>
        Back
      </button>
    </div>
  </div>
);

Demo.propTypes = {
  BackToMainScreen: PropTypes.func,
};

export default Demo;
