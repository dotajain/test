import React from 'react';
import PropTypes from 'prop-types';

import logo from '../../assets/images/WhirlpoolCorp-2017Logo_2C_B.png';

const Header = ({ ...props }) => (
  <nav className="navbar navbar-expand-md navbar-default fixed-top bg-white">
    <a href="#" className="navbar-brand">
      <img width="120" src={logo} alt="Whirlphool Logo" />
    </a>
    <div className="collapse navbar-collapse">

      <button onClick={props.logout} className="btn btn-outline-primary ml-auto my-2 my-sm-0">Logout</button>
    </div>
  </nav>
);


Header.propTypes = {
  logout: PropTypes.func.isRequired,
};

export default Header;
