import React from 'react';
import _ from 'lodash';
import PropTypes from 'prop-types';

const CardIngredients = ({ ...props }) => {
  const ingredientsItem = _.map(props.data, (item, i) => {
    return (
      <li  className="ingredients--item" key={i}>
        <div className="ingredient">
        <input type="checkbox" checked={item.available} name="checkbox" id={`checkbox${i}`} />
        <label htmlFor={`checkbox${i}`}>{item.name}</label>
      </div>
    </li>
    );
  });
  return (
    <div className="card ingredients-card text-white">
      <div className="card-header">
        Recipe Ingredients
      </div>
      <div className="card-body">
        <ul className="ingredients">
          {ingredientsItem}
        </ul>
      </div>
    </div>
  );
};

CardIngredients.propTypes = {
  data: PropTypes.array,
};

export default CardIngredients;
