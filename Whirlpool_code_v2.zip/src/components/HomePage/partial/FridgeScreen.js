import React from 'react';
import PropTypes from 'prop-types';

import _ from 'lodash';

import FridgeButton from './FridgeButton';


const FridgeScreen = ({ ...props }) => {
  const { fridgeData } = props;
  const tabButtons = _.map(fridgeData, (item, i) => {
    return (
      <FridgeButton
          key={i}
          data={item}
          handleClick={props.handleClick}
        />
    );
  });
  
  return (
    <div className="main-page fridge-page">
      <div className="fridge-row row">
        <div className="fridge--tab col-sm-2">
          <div className="fridge--list">
            <div className="section-header no-image">
            </div>
            {tabButtons}
          </div>
        </div>
        <div className="fridge-big col-sm-10">
          <div className="image--container">
            <img src={ props.activeImage.image } alt="image" />
          </div>
        </div>
      </div>

      <div className="main--footer">
        <button className="btn btn-outline-secondary back-button" onClick={props.BackToMainScreen}>
          Back
        </button>
        <button className="btn btn-primary" onClick={() => props.CameraView(props.activeImage)}>
          Individual Camera View
        </button>
      </div>
    </div>
  );
};

FridgeScreen.propTypes = {
  fridgeData: PropTypes.array,
  CameraView: PropTypes.func,
  BackToMainScreen: PropTypes.func,
  handleClick: PropTypes.func,
  activeImage: PropTypes.object,

};

export default FridgeScreen;