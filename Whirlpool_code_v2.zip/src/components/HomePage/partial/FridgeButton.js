import React from 'react';
import PropTypes from 'prop-types';

const FridgeButton = ({ ...props }) => (
  <div className="fridge--image-wrap">
    <button className="fridge--btn" onClick={() => props.handleClick(props.data)}>
      <div className="brand">Whirlpool</div>
      <div className="fridge--image">
        <img src={props.data.image} alt="fridge" />
      </div>
      <h3>{props.data.name}</h3>
    </button>
  </div>
);

FridgeButton.propTypes = {
  handleClick: PropTypes.func,
  data: PropTypes.object,
};

export default FridgeButton;
