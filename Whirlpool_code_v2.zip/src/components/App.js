import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Route, Redirect, withRouter } from 'react-router-dom';
import Async from 'react-code-splitting';
import { logout } from '../actions';
import Login from './Auth/Login';
import Header from './Header';

const Home = () => <Async load={import('./Home')} />;

const App = ({ user, logout }) => {
  
  // user.token ? null : window.location.href = window.location.origin;
  return (
    <main>
      {user.token ? <Header logout={logout} /> : null }
      {user.token ? <Redirect to="/home" /> : <Redirect to="/" />}
      
      <Route exact path="/" component={Login} />
      <Route exact path="/home" component={Home} />
    </main>
  );
};

App.propTypes = {
  user: PropTypes.shape({}).isRequired,
  logout: PropTypes.func,
};

export default withRouter(connect(state => ({ user: state.user.login }), { logout } )(App));
