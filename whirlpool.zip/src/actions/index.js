import { actionTypes as types } from '../constants';
// import { post } from '../helpers';

export const login = () => dispatch => {
  dispatch({ type: types.LOGIN_REQUEST });
  dispatch({ type: types.LOGIN_SUCCESS,
    data: {
      token: 'QpwL5tke4Pnpja7X',
    }});
};

export const logout = () => dispatch => {
  dispatch({ type: types.LOGOUT_REQUEST });
};

export const getFridgeData = () => dispatch => {
  dispatch({ type: types.FRIDGE_DATA, data: fridgeScreenData });
};


const fridgeScreenData = [
  {
    'id': 0,
    'name': 'Whirlpool WRS325SDHZ',
    'image': 'https://whirlpoolblob.blob.core.windows.net/whirlpool/Whirlpool%20%20WRS325SDHZ/Whirlpool%20%20WRS325SDHZ%2036%20Inch%20Side-by-Side%20Refrigerator.png',
    'thumbnails': [
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/Whirlpool%20%20WRS325SDHZ/Whirlpool%20%20WRS325SDHZ%20_1.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/Whirlpool%20%20WRS325SDHZ/Whirlpool%20%20WRS325SDHZ%20_2.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/Whirlpool%20%20WRS325SDHZ/Whirlpool%20%20WRS325SDHZ%20_3.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/Whirlpool%20%20WRS325SDHZ/Whirlpool%20%20WRS325SDHZ%20_4..png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/Whirlpool%20%20WRS325SDHZ/Whirlpool%20%20WRS325SDHZ%20_5.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/Whirlpool%20%20WRS325SDHZ/Whirlpool%20%20WRS325SDHZ%20_6.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/Whirlpool%20%20WRS325SDHZ/Whirlpool%20%20WRS325SDHZ%20_7.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/Whirlpool%20%20WRS325SDHZ/Whirlpool%20%20WRS325SDHZ%20_8.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/Whirlpool%20%20WRS325SDHZ/Whirlpool%20%20WRS325SDHZ%20_9.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/Whirlpool%20%20WRS325SDHZ/Whirlpool%20%20WRS325SDHZ%20_10.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/Whirlpool%20%20WRS325SDHZ/Whirlpool%20%20WRS325SDHZ%20_11.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/Whirlpool%20%20WRS325SDHZ/Whirlpool%20%20WRS325SDHZ%20_12.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/Whirlpool%20%20WRS325SDHZ/Whirlpool%20%20WRS325SDHZ%20_13.png',
        'tags': '',
        'ocr': '',
      },
    ],
  },
  {
    'id': 1,
    'name': 'Whirlpool WRS571CIDM',
    'image': 'https://whirlpoolblob.blob.core.windows.net/whirlpool/Whirlpool%20%20WRS571CIDM/Whirlpool%20%20WRS571CIDM%2036%20Inch%20Counter%20Depth%20Side-by-Side%20Refrigerator.png',
    'thumbnails': [
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/Whirlpool%20%20WRS571CIDM/Whirlpool%20%20WRS571CIDM%20_1.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/Whirlpool%20%20WRS571CIDM/Whirlpool%20%20WRS571CIDM%20_2.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/Whirlpool%20%20WRS571CIDM/Whirlpool%20%20WRS571CIDM%20_3.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/Whirlpool%20%20WRS571CIDM/Whirlpool%20%20WRS571CIDM%20_4.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/Whirlpool%20%20WRS571CIDM/Whirlpool%20%20WRS571CIDM%20_5.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/Whirlpool%20%20WRS571CIDM/Whirlpool%20%20WRS571CIDM%20_6.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/Whirlpool%20%20WRS571CIDM/Whirlpool%20%20WRS571CIDM%20_7.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/Whirlpool%20%20WRS571CIDM/Whirlpool%20%20WRS571CIDM%20_8.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/Whirlpool%20%20WRS571CIDM/Whirlpool%20%20WRS571CIDM%20_9.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/Whirlpool%20%20WRS571CIDM/Whirlpool%20%20WRS571CIDM%20_10.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/Whirlpool%20%20WRS571CIDM/Whirlpool%20%20WRS571CIDM%20_11.png',
        'tags': '',
        'ocr': '',
      },
    ],
  },
  {
    'id': 2,
    'name': 'Whirlpool 200 L',
    'image': 'https://whirlpoolblob.blob.core.windows.net/whirlpool/WRX735SDHX/WRX735SDHX.png',
    'thumbnails': [
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/WRX735SDHX/WRX735SDHX_1.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/WRX735SDHX/WRX735SDHX_2.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/WRX735SDHX/WRX735SDHX_3.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/WRX735SDHX/WRX735SDHX_4.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/WRX735SDHX/WRX735SDHX_5.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/WRX735SDHX/WRX735SDHX_6.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/WRX735SDHX/WRX735SDHX_7.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/WRX735SDHX/WRX735SDHX_8.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/WRX735SDHX/WRX735SDHZ_shelf.png',
        'tags': '',
        'ocr': '',
      },
    ],
  },
  {
    'id': 3,
    'name': 'Whirlpool 570 L',
    'image': 'https://whirlpoolblob.blob.core.windows.net/whirlpool/WRF992FIFE/WRF992FIFE_1.png',
    'thumbnails': [
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/WRF992FIFE/WRF992FIFE_2.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/WRF992FIFE/WRF992FIFE_3.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/WRF992FIFE/WRF992FIFE_4.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/WRF992FIFE/WRF992FIFE_5.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/WRF992FIFE/WRF992FIFE_6.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/WRF992FIFE/WRF992FIFE_7.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/WRF992FIFE/WRF992FIFE_8.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/WRF992FIFE/WRF992FIFE_9.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/WRF992FIFE/WRF992FIFE_10.png',
        'tags': '',
        'ocr': '',
      },
      {
        url: 'https://whirlpoolblob.blob.core.windows.net/whirlpool/WRF992FIFE/WRF992FIFE_11.png',
        'tags': '',
        'ocr': '',
      },
    ],
  },
];
