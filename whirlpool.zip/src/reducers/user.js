import { actionTypes as types } from '../constants';

const initialState = {
  login: {},
  fridgeData: [],
};

const user = (state = initialState, action) => {
  switch (action.type) {
  case types.SIGNUP_SUCCESS:
  case types.LOGIN_SUCCESS:
    return {...state, login: action.data};
  case types.LOGIN_FAILURE:
    return {...state, login: {}};
  case types.LOGOUT_REQUEST:
    return {...state, login: {}};
  case types.FRIDGE_DATA:
    return {...state, fridgeData: action.data};
  default:
    return state;
  }
};

export default user;

