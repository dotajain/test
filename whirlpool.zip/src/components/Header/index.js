import React from 'react';
import PropTypes from 'prop-types';
const Header = ({ ...props }) => (
  <nav className="navbar navbar-expand-md navbar-default fixed-top bg-white">
    <a href="#" className="navbar-brand">
      <img width="120" src="http://assets.whirlpoolcorp.com/logos/WhirlpoolCorp-2017Logo_2C_B.png" alt="Whirlphool Logo" />
    </a>
    <div className="collapse navbar-collapse">
      <div className="recipe-other">
        <div className="recipe-detail-other">
          <div className="row">
            <div className="col-md-3 col-sm-3 col-xs-6 recipe-detail-component">
              <div className="col-md-4">
                <img src="http://cakeart.thimpress.com/wp-content/themes/cakeart//images/admin/recipe-detail/prep-time.png" alt="recipe detail" />
              </div>
              <div className="col-md-8">
                <em>Prep Time</em>
                <p className="detail-info">5 minutes</p>
              </div>
            </div><div className="col-md-3 col-sm-3 col-xs-6 recipe-detail-component">
              <div className="col-md-4">
                <img src="http://cakeart.thimpress.com/wp-content/themes/cakeart//images/admin/recipe-detail/cook-time.png" alt="recipe detail" />
              </div>
              <div className="col-md-8">
                <em>Cook Time</em>
                <p className="detail-info">10 minutes</p>
              </div>
            </div>
            <div className="col-md-3 col-sm-3 col-xs-6 recipe-detail-component">
              <div className="col-md-4">
                <img src="http://cakeart.thimpress.com/wp-content/themes/cakeart//images/admin/recipe-detail/yield.png" alt="recipe detail" />
              </div>
              <div className="col-md-8">
                <em>Yield</em>
                <p className="detail-info">6 Rolls</p>
              </div>
            </div>
            <div className="col-md-3 col-sm-3 col-xs-6 recipe-detail-component">
              <div className="col-md-4">
                <img src="http://cakeart.thimpress.com/wp-content/themes/cakeart//images/admin/recipe-detail/servings.png" alt="recipe detail" />
              </div>
              <div className="col-md-8">
                <em>Servings</em>
                <p className="detail-info">For Family</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="ml-auto">
        <button onClick={props.logout} className="btn btn-outline-primary my-2 my-sm-0">Logout</button>
      </div>
    </div>
  </nav>
);


Header.propTypes = {
  logout: PropTypes.func.isRequired,
};

export default Header;
